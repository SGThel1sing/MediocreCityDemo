﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class AttackBox : MonoBehaviour
{
    private enum AttacksWhat { Enemy, Player }
    [SerializeField] private AttacksWhat attacksWhat;
    [SerializeField] private int attackPower;
    [SerializeField] private int targetSide;


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        // if I'm at an 'x' positions  that is smaler that I'm attack(col), I'm om left side (-1).
        // Otherwise I'm on right(1).
        if (transform.parent.transform.position.x < col.transform.position.x)
        {
            targetSide = -1;
        }
        else
        {
            targetSide = 1;
        }

        if (attacksWhat == AttacksWhat.Enemy)
        {
            //if touch the enemy, hurt the enemy
            if (col.gameObject.GetComponent<Enemy>())
            {
                //col.gameObject.GetComponent<Enemy>.health -= NewPlayer.Instance.AttackPower;
                col.gameObject.GetComponent<Enemy>().Hurt();

            }
        }
        else if (attacksWhat == AttacksWhat.Player)
        {
            if (col.gameObject == NewPlayer.Instance.gameObject)
            {
                // hurt the player, then update UI
                NewPlayer.Instance.Hurt();
            }
        }
    }
}
