﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;

public class SceneLoadTrigger : MonoBehaviour
{
    [SerializeField] private string loadSceneString;
    [SerializeField] private bool destroyPlayer;


    // Start is called before the first frame update
    void Start()
    {
        SceneManager.sceneLoaded += (scene, mode) => { NewPlayer.Instance.SetSpawnPosition(); };
    }
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject == NewPlayer.Instance.gameObject)
        {
            NewPlayer.Instance.LoadLevel(loadSceneString);
            if (destroyPlayer)
            {
                Destroy(NewPlayer.Instance.gameObject);
                Destroy(GameManager.Instance.gameObject);
            }
        }
    }
}
